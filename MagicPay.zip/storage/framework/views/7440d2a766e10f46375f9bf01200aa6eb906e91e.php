<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,400;1,300&display=swap" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

    <link rel="stylesheet" href="<?php echo e(asset('frontend/style.css')); ?>">

    
    <?php echo $__env->yieldContent('custom_css'); ?>

</head>
<body>

    
         

        <div class="header-menu">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-8" >
                    <div class="row">
                        <div class="col-2 text-center">
                            <?php if(!request()->is('/')): ?>
                            <a href="#" id="back">
                                <i class="fas fa-angle-left"></i>
                            </a>
                            <?php endif; ?>

                        </div>
                        <div class="col-8 text-center">
                            <h3>
                                <?php echo $__env->yieldContent('title'); ?>
                            </h3>
                        </div>
                        <div class="col-2 text-center">
                            <div >
                                <a href="<?php echo e(route('notifications')); ?>" style="position: relative">
                                    <i class="fas fa-bell mb-2" >
                                    </i>
                                    <?php if(!empty($unread_noti_count)): ?>
                                    <div class="badge badge-danger app_notifiation_count" style=""><?php echo e($unread_noti_count); ?></div>
                                    <?php endif; ?>
                                </a>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


        
        <div style="padding-top: 100px; padding-bottom : 120px">
            <div class="container">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>




        <div class="button-menu">
            <a href="<?php echo e(route('san_and_pay')); ?>" class="scan-tab">
                <div class="inside">
                    <i class="fas fa-qrcode"></i>
                </div>
            </a>
            <div class="row justify-content-center">
                <div class="col-md-8" >
                    <div class="row">
                        <div class="col-3 text-center">
                            <a href="<?php echo e(route('home')); ?>" >
                                <i class="fas fa-home"></i>
                                <p>Home</p>
                            </a>
                        </div>
                        <div class="col-3 text-center">
                            <a href="<?php echo e(route('wallet')); ?>">
                                <i class="fas fa-wallet"></i>
                                <p>Wallet</p>
                            </a>
                        </div>
                        <div class="col-3 text-center">
                            <a href="<?php echo e(route('transactions_list')); ?>">
                                <i class="fas fa-exchange-alt"></i>
                                <p>Transaction</p>
                            </a>
                        </div>
                        <div class="col-3 text-center">
                            <a href="<?php echo e(route('profile')); ?>">
                                <i class="fas fa-user"></i>
                                <p>Account</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    



    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>

    <script src="https://unpkg.com/@popperjs/core@2" ></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <script  src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

    <script>
   $(document).ready(function() {

        let token =document.head.querySelector('meta[name="csrf_token"]');
        if(token){
            $.ajaxSetup({
                headers :{
                    'X-CSRF-TOKEN' : token.content,
                    'Content-type' : 'Application/json',
                    'Accept' : 'Application/json',
                }
            })
        }

        $( "#back" ).click(function(e) {
            e.preventDefault();
            window.history.back();
            return false;
        });

        //sweet alert
        const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                    })

                    <?php if(session('success')): ?>
                    Toast.fire({
                    icon: 'success',
                    title: "<?php echo e(session('success')); ?>"
                    })
                    <?php endif; ?>


     });
    </script>
    
    <?php echo $__env->yieldContent('custom_script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>