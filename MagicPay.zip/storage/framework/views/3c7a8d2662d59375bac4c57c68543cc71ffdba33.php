<?php $__env->startSection('title','Notification'); ?>

<?php $__env->startSection('content'); ?>

        <div class="card noti-details">
            <div class="card-body"><div class="text-center">
                <img src="<?php echo e(asset('img/scan_and_pay.png')); ?>" alt="" width="200">
            </div>
            <div class="text-center">
                <h6><?php echo e($notification->data['title']); ?></h6>
                <h6 class="mb-3"><?php echo e($notification->data['message']); ?></h6>
                <a href="<?php echo e($notification->data['web_link']); ?>" class="btn btn-theme btn-sm">Continue</a>
            </div>
        </div>

        </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/notification_details.blade.php ENDPATH**/ ?>