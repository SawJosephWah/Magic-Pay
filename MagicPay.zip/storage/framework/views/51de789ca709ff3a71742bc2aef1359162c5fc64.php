<?php $__env->startSection('title','User'); ?>

<?php $__env->startSection('user-active','mm-active'); ?>

<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-users icon-gradient bg-mean-fruit">
                </i>
            </div>
            <div>User
            </div>
        </div>

    </div>
</div>

<a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-primary">
    <i class="fas fa-plus-circle"></i>
    Create User
</a>




<div class="content mt-3">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="admins">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Login at</th>
                            <th>Ip</th>
                            <th class="no-sort">User Agent</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th class="no-sort">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom-script'); ?>
<script>
    //default csrf
    $(document).ready(function() {
        let token =document.head.querySelector('meta[name="csrf_token"]');
        if(token){
            $.ajaxSetup({
                headers :{
                    'X-CSRF-TOKEN' : token.content
                }
            })
        }


   let datatable =  $('#admins').DataTable( {
        "responsive": true,
        "processing": true,
        "serverSide": true,
        "ajax": "/admin/user/datatable/ssd",
        columns :[
        {
            data : 'name',
            name : 'name'
        },
        {
            data : 'email',
            name : 'email'
        },
        {
            data : 'phone',
            name : 'phone'
        },
        {
            data : 'login_at',
            name : 'login_at'
        },
        {
            data : 'ip',
            name : 'ip'
        },
        {
            data : 'user_agent',
            name : 'user_agent'
        },
        {
            data : 'created_at',
            name : 'created_at'
        },
        {
            data : 'updated_at',
            name : 'updated_at'
        },
        {
            data : 'action',
            name : 'action',
            sortable : false,
        }
        ],
        order: [
            [ 7, "desc" ]
            ],
        columnDefs : [{
            targets : 'no-sort',
            sortable : false,
            searchable : false
        }]
    } );

    //delete
    $(document).on('click','#delete-btn',function(e){
        e.preventDefault();

        let id = $(this).data('id');


        Swal.fire({
            title: 'Do you want to save the changes?',
            showCancelButton: true,
            confirmButtonText: `Confirm`,
            }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: `/admin/user/${id}`,
                    type : 'DELETE',
                    success : function(){
                        datatable.ajax.reload();
                    }
                });
            }
            })
    })
} );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/Backend/User/index.blade.php ENDPATH**/ ?>