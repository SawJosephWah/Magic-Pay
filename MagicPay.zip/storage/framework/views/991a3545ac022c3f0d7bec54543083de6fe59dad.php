<?php $__env->startSection('user-active','mm-active'); ?>

<?php $__env->startSection('content'); ?>
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-users icon-gradient bg-mean-fruit">
                </i>
            </div>
            <div>Create Admin User
            </div>
        </div>

    </div>
</div>


<div class="content mt-3">
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control"  name="email" value="<?php echo e($user->email); ?>">
                </div>

                <div class="form-group">
                    <label>Phone</label>
                    <input type="number" class="form-control" name="phone" value="<?php echo e($user->phone); ?>">
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="number" class="form-control" name="password">
                </div>

                <div class="d-flex justify-content-center">
                    <button class="btn btn-secondary mr-3" id="back-btn">Back</button>
                    <button class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-script'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\UpdateUser'); ?>

<script>
    $(document).ready(function() {
} );
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/backend/User/edit.blade.php ENDPATH**/ ?>