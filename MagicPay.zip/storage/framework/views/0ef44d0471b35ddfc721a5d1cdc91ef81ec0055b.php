<?php $__env->startSection('title','Transaction Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="transaction_details">
        <div class="card mt-3">
            <div class="card-body p-3">
                <div class="text-center mb-3">
                    <img src="<?php echo e(asset('img/checked.png')); ?>" alt="">
                </div>
                <p class="text-center <?php if($transaction_datials->type == 1): ?> text-success <?php else: ?> text-danger <?php endif; ?>">
                    <?php echo e(number_format($transaction_datials->amount)); ?> MMK
                </p>

                <div class="d-flex justify-content-between">
                    <p class="mb-0 text-muted">Trx_ID</p>
                    <p class="mb-0"><?php echo e($transaction_datials->transaction_id); ?></p>
                </div>
                <hr>

                <div class="d-flex justify-content-between">
                    <p class="mb-0 text-muted">Reference_Id</p>
                    <p class="mb-0"><?php echo e($transaction_datials->ref_id); ?></p>
                </div>
                <hr>

                <div class="d-flex justify-content-between">
                    <p class="mb-0 text-muted">Type</p>
                    <?php if($transaction_datials->type == 1): ?>
                    <span class="badge badge-success">INCOME</span>
                    <?php else: ?>
                    <span class="badge badge-danger">EXPENCE</span>
                    <?php endif; ?>
                </div>
                <hr>

                <div class="d-flex justify-content-between">
                    <p class="mb-0 text-muted">Amount</p>
                    <p class="mb-0"><?php echo e(number_format($transaction_datials->amount,2)); ?> MMK</p>
                </div>
                <hr>

                <div class="d-flex justify-content-between">
                    <p class="mb-0 text-muted">Date and Time</p>
                    <p class="mb-0"><?php echo e($transaction_datials->created_at); ?></p>
                </div>
                <hr>

                <div class="d-flex justify-content-between">
                    <?php if($transaction_datials->type == 1): ?>
                    <p class="mb-0 text-muted">From</p>
                    <?php else: ?>
                    <p class="mb-0 text-muted">To</p>
                    <?php endif; ?>
                    <p class="mb-0"><?php echo e($transaction_datials->source->name); ?></p>
                </div>
                <hr>

                <div class="d-flex justify-content-between">
                    <p class="mb-0 text-muted">Description</p>
                    <p class="mb-0"><?php echo e($transaction_datials->description); ?></p>
                </div>
                <hr>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/transactionDetails.blade.php ENDPATH**/ ?>