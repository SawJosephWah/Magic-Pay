<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link href="<?php echo e(asset('backend/css/main.css')); ?>" rel="stylesheet"></head>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.0/css/dataTables.bootstrap4.min.css">

    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo e(asset('backend/css/style.css')); ?>">

    <?php echo $__env->yieldContent('custom-css'); ?>
<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
       <?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="app-main">
                <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="container-fluid">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>



                    </div>

                    <div class="app-wrapper-footer">
                        <div class="app-footer">
                            <div class="app-footer__inner">
                                <div class="app-footer-left">
                                    Copyright <?php echo e(date('Y')); ?>. All reserved by Magic Pay
                                </div>
                                <div class="app-footer-right">
                                    Developed By Joseph Jo
                                </div>
                            </div>
                        </div>
                    </div>    </div>

        </div>
    </div>


<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.0/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('backend/scripts/main.js')); ?>"></script></body>


<script type="text/javascript" src="<?php echo e(url('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>


<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


<link rel="stylesheet" href="/path/to/select2.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@x.x.x/dist/select2-bootstrap4.min.css">

<script>
     $(document).ready(function() {
        $(document).ready(function() {
        let token =document.head.querySelector('meta[name="csrf_token"]');
        if(token){
            $.ajaxSetup({
                headers :{
                    'X-CSRF-TOKEN' : token.content
                }
            })
        }

        $('#back-btn').on('click',function(){
            window.history.go(-1);
            return false;
        })
        });

                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                    })

                    <?php if(session('create')): ?>
                    Toast.fire({
                    icon: 'success',
                    title: "<?php echo e(session('create')); ?>"
                    })
                    <?php endif; ?>

                    <?php if(session('update')): ?>
                    Toast.fire({
                    icon: 'success',
                    title: "<?php echo e(session('update')); ?>"
                    })
                    <?php endif; ?>
     });


</script>

<?php echo $__env->yieldContent('custom-script'); ?>



</html>
<?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>