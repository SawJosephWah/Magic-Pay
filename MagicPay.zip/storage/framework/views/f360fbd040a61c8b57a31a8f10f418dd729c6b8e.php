<?php $__env->startSection('title','Wallet'); ?>

<?php $__env->startSection('content'); ?>

        <div class="card wallet-card">
            <div class="card-body">
                <div class="mb-4">
                    <h6>Balance</h6>
                    <h3><?php echo e($user->wallets ? number_format($user->wallets->amount, 2) : '0.00'); ?> <span style="font-size: 15px">MMK</span></h3>
                </div>
                <div class="mb-5">
                    <h6>Account Number</h6>
                    <h3><?php echo e($user->wallets ? $user->wallets->account_number : '-'); ?></h3>
                </div>
                <div>
                    <h3><?php echo e($user->name); ?></h3>
                </div>

            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/wallet.blade.php ENDPATH**/ ?>