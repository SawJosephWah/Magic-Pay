<?php $__env->startSection('title','Magic Pay'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">

                    <div class="profile mb-3">
                        <img src="https://ui-avatars.com/api/?background=5842E3&color=fff&name=<?php echo e($user->name); ?>" alt="">
                    </div>
                    <p class="text-center"><?php echo e($user->name); ?></p>
                    <h5 class="text-center mb-3"><?php echo e(number_format($user->wallets->amount,2)); ?> MMK</h5>

        </div>


        <div class="col-6 mb-3">
            <a href="<?php echo e(route('san_and_pay')); ?>">
                <div class="card shortcut-card">
                    <div class="card-body p-3">
                        <img src="<?php echo e(asset('img/qr-code-scan.png')); ?>" alt="">
                        Scan & pay
                    </div>
                </div>
            </a>

        </div>
        <div class="col-6 mb-3">
            <a href="<?php echo e(route('scannerqr')); ?>">
                <div class="card shortcut-card">
                    <div class="card-body p-3">
                        <img src="<?php echo e(asset('img/qr-code.png')); ?>" alt="">
                        Receive QR
                    </div>
                </div>
            </a>

        </div>

        <div class="col-12">
            <div class="card mb-3">
                <div class="card-body function-bar">
                    <a href="<?php echo e(route('transfer')); ?>" class="updatepassword">
                        <div class="d-flex justify-content-between">
                            <span>
                                <img src="<?php echo e(asset('img/money-transfer.png')); ?>" alt="">
                                Transfer</span>
                            <span><i class="fas fa-angle-right"></i></span>
                        </div>
                    </a>

                    <hr>
                    <a href="<?php echo e(route('wallet')); ?>" class="d-flex justify-content-between " id="logout">
                        <span>
                            <img src="<?php echo e(asset('img/wallet.png')); ?>" alt="">
                            Wallet</span>
                        <span><i class="fas fa-angle-right"></i></span>
                    </a>

                    <hr>
                    <a href="<?php echo e(route('transactions_list')); ?>" class="d-flex justify-content-between " >
                        <span>
                            <img src="<?php echo e(asset('img/transaction.png')); ?>" alt="">
                            Transaction</span>
                        <span><i class="fas fa-angle-right"></i></span>
                    </a>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/home.blade.php ENDPATH**/ ?>