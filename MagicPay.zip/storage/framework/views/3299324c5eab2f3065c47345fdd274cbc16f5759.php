<?php $__env->startSection('title','QR Scanner'); ?>

<?php $__env->startSection('content'); ?>

        <div class="card qr-scanner">
            <div class="card-body">
                <p class="m-0 text-center">Scan To Pay Me</p>
                <div class="text-center">
                    <img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(300)->generate($user->phone)); ?> ">
                </div>
                <p class="m-0 text-center"><?php echo e($user->name); ?></p>
                <p class="m-0 text-center text-muted"><?php echo e($user->phone); ?></p>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/scanner_qr.blade.php ENDPATH**/ ?>