@extends('backend.layouts.app')

@section('title')
    Admin Dashboard
@endsection

@section('content')
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="pe-7s-display2 icon-gradient bg-mean-fruit">
                </i>
            </div>
            <div>Dashboard
            </div>
        </div>

    </div>
</div>
@endsection


@section('home-active','mm-active')
