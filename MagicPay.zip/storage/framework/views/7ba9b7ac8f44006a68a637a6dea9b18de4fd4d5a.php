<?php $__env->startSection('title','Notifications'); ?>

<?php $__env->startSection('content'); ?>
    <div class="notification_list">
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('notificationDetails',$notification->id)); ?>">
            <div class="card notification_list mb-2">
                <div class="card-body p-3">
                    <h6 class="mb-1"><i class="fas fa-bell mr-2 <?php if(!isset($notification->read_at)): ?> text-danger <?php endif; ?>"></i><?php echo e(Illuminate\Support\Str::limit( $notification->data['title'], 20)); ?></h6>
                    <p class="m-0"><?php echo e(Illuminate\Support\Str::limit($notification->data['message'], 50)); ?></p>
                    <div class="d-flex justify-content-end">
                        <small class="m-0 text-muted"><?php echo e(date('Y-m-d h:i A', strtotime($notification->created_at))); ?></small>
                    </div>
                </div>
            </div>
        </a>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/notifications.blade.php ENDPATH**/ ?>