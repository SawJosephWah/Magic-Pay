<?php $__env->startSection('title','Transactions'); ?>

<?php $__env->startSection('content'); ?>
    <div class="transaction_list">
        <div class="card mb-2">
            <div class="card-body p-2">
                <div class="row align-items-center">

                    <div class="col-6 col-md-3">
                        <div class="input-group my-2">
                            <div class="input-group-prepend">
                              <label class="input-group-text" for="inputGroupSelect01">Date</label>
                            </div>
                            <input class="form-control" type="text" id="date" value="<?php echo e(request()->date); ?>" placeholder="All">
                          </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="input-group my-2">
                            <div class="input-group-prepend">
                              <label class="input-group-text" for="inputGroupSelect01">Type</label>
                            </div>
                            <select class="custom-select" id="type">
                              <option value="">All</option>
                              <option value="1" <?php if(request()->type == 1): ?> selected <?php endif; ?>>Income</option>
                              <option value="2" <?php if(request()->type == 2): ?> selected <?php endif; ?>>Expence</option>
                            </select>
                          </div>
                    </div>

                    <div class="col-4 col-md-2">
                        <a href="<?php echo e(route('transactions_list')); ?>">
                            <p class=" p-2 m-0 rounded unique_btn my-auto">All Transaction</p>
                        </a>
                    </div>
                    <div class="col-4 col-md-2">
                        <p class=" p-2 m-0 rounded unique_btn my-auto all_expences_btn ">All Expences</p>
                    </div>
                    <div class="col-4 col-md-2">
                        <p class=" p-2 m-0 rounded unique_btn my-auto all_expences_incomes">All Incomes</p>
                    </div>

                </div>
            </div>
        </div>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('transaction.details',$transaction->transaction_id)); ?>">
            <div class="card transaction_list mb-2">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between">

                        <h6 class="mb-1"> Trx_ID : <?php echo e($transaction->transaction_id); ?></h6>
                        <h6 class="mb-1 <?php if($transaction->type == 1): ?> text-success <?php else: ?> text-danger <?php endif; ?>"><?php echo e($transaction->amount); ?></h6>
                    </div>
                    <p class="text-muted mb-0">
                        <?php if($transaction->type == 1): ?> From <?php else: ?> To <?php endif; ?>
                        - <?php if($transaction->source == null): ?>
                            Admin
                            <?php else: ?>
                            <?php echo e($transaction->source->name); ?>

                            <?php endif; ?>
                        <br>

                        <?php echo e($transaction->created_at); ?>

                    </p>


                </div>
            </div>
        </a>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
    <script>
        $( document ).ready(function() {
            $('#date').daterangepicker({
                "singleDatePicker": true,
                "autoApply": false,
                "autoUpdateInput" : false,
                "locale": {
                    "format": "YYYY-MM-DD"
            }});

            $('#date').on('apply.daterangepicker', function(ev, picker) {
                $(this).val(picker.startDate.format('YYYY-MM-DD'));
                let date = $('#date').val();
                let type = $( "#type option:selected" ).val();

                history.pushState('','',`?date=${date}&type=${type}`);
                location.reload();
            });

            $('#date').on('cancel.daterangepicker', function(ev, picker) {
                $(this).val('');
                let date = $('#date').val();
                let type = $( "#type option:selected" ).val();

                history.pushState('','',`?date=${date}&type=${type}`);
                location.reload();
            });


            $( "#type" ).change(function(){
                let date = $('#date').val();
                let type = $( "#type option:selected" ).val();

                history.pushState('','',`?date=${date}&type=${type}`);
                location.reload();
            });

            $( ".all_expences_btn" ).on('click',function(){
                location.replace(`/transactions?type=2`);
            });

            $( ".all_expences_incomes" ).on('click',function(){
                location.replace(`/transactions?type=1`);
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/transactionList.blade.php ENDPATH**/ ?>