<?php $__env->startSection('title','Transfer'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('transfer')); ?>" method="POST" id="form">
                        <?php echo csrf_field(); ?>
                        <input   value="<?php echo e($hashed_value); ?>" name="hashed_value" type="hidden">
                        <input   value="<?php echo e($to_user->phone); ?>" name="to_phone" type="hidden">
                        <input   value="<?php echo e($amount); ?>" name="amount" type="hidden">
                        <input   value="<?php echo e($description); ?>" name="description" type="hidden">
                    </form>


                    <div class="mb-3">
                        <h5 for="" class="mb-1 text-bold">From</h5>
                        <p class="text-muted mb-0"><?php echo e($auth_user->name); ?></p>
                        <p class="text-muted"><?php echo e($auth_user->phone); ?></p>
                    </div>
                    <form action="<?php echo e(route('transfer.confirm')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <h5 for="" class="mb-1 text-bold">To</h5>
                            <p class="text-muted mb-0"><?php echo e($to_user->name); ?></p>
                            <p class="text-muted mb-0"><?php echo e($to_user->phone); ?></p>
                        </div>

                        <div class="mb-3">
                            <h5 for="" class="mb-1 text-bold">Amount</h5>
                            <p class="text-muted mb-0"><?php echo e($amount); ?></p>
                        </div>

                        <div class="mb-3">
                            <h5 for="" class="mb-1 text-bold">Description</h5>
                            <p class="text-muted mb-0"><?php echo e($description); ?></p>
                        </div>

                        <button class="btn btn-primary btn-block my-5 btn-theme" id="confirm" type="submit">Confirm</button>
                    </form>

                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>
    <script>
        $( document ).ready(function() {
            $( "#confirm" ).on( "click", function(e) {
                e.preventDefault();


                Swal.fire({
                title: 'Fill your password',
                icon: 'info',
                html:
                    `<input type="password" class="form-control text-center password" autofocus>`,
                showCloseButton: true,
                showCancelButton: true,
                confirmButtonText: 'Confirm',
                reverseButtons : true
                }).then((result) => {
                    if (result.isConfirmed) {
                        let password = $('.password').val();

                    $.ajax({
                    url: `/transfer_password_check?password=${password}`,
                    type : 'GET',
                    success: function(res){
                        console.log(res.status);
                        if(res.status == 'success'){
                            $( "#form" ).submit();
                        }else if(res.status == 'fail'){

                            Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Wrong Password! Try Again'
                            })
                        }
                    },
                });
                    }


                    })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_dev_cha\MagicPay\resources\views/frontend/transferConfirm.blade.php ENDPATH**/ ?>